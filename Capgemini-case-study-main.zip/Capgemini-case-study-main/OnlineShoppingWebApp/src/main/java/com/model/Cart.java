package com.model;

import java.util.List;

public class Cart {
	private List<Product> productList;
	private float cartAmt;
	

}
