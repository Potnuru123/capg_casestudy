package com.model;

public enum Rating {
	EXCELLENT,
	GOOD,
	AVERAGE,
	POOR
	
}
