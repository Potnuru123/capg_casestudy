package com.model;

public enum AttendenceType {
	PRESENT,
	ABSENT,
	LEAVE,
	NOT_MARKED
	

}
